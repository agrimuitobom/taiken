"""
畑のステータス表示 - フェーズ2（DHT22 + ADC0834 + リレー＋ポンプ）
=================================================================
フェーズ1（見える）に「動く」を足したもの。
土壌水分がしきい値を下回るとポンプが自動で回り、
ブラウザのスライダーからそのしきい値を変更できる。

【フェーズ1からの変更点】
  1. リレー（GPIO17）でポンプを制御する処理を追加
  2. 土壌水分をDHT22とは独立して更新するよう修正
     （DHT22のRuntimeErrorでかん水判定が止まらないように）
  3. /api/threshold, /api/water, /api/auto を追加
  4. 末尾に重複していたルート定義を削除

【この版で追加した誤作動対策】
  1. 連続3回（約6秒）乾いていたときだけ水をやる
     → センサーの抜き差しで一瞬値が飛んでもポンプが回らない
  2. 自動かん水が5回続いても水分が上がらなければ自動を停止する
     → センサーを土から抜きっぱなしにしても水が出続けない
     → 土に戻して水分が回復すればカウンタは自動でリセットされる
  3. 自動が止まっても「いますぐ みずやり」の手動作動はできる
     自動を再開するには /api/auto に enabled:true を送る
  4. 「みずやりを とめる」ボタン（/api/stop）でいつでも即停止できる
     停止すると自動かん水も切れる。再開はブラウザの再開ボタンから

【v4 の変更】
  給水時間を「3秒固定」から「しきい値に達するまで」に変更した。
  0.1秒ごとに土壌水分を見て、目標に届いた時点で即座に止まる。
  ただし水切れや空回しを防ぐため、最長 PUMP_MAX_SEC（初期15秒）で
  強制停止する。センサーの読み取りは1秒間隔。

【v3 の重要な変更】
  リレーがOFFにならない問題への対応。
  安価なリレーモジュールは VCC=5V で動くのに Pi の HIGH は 3.3V しかなく、
  その差でフォトカプラが光り続け、HIGH を出しても OFF にならないことがある
  （IN線を抜いたときだけ消える、という症状）。
  そこで OFF のときはピンを入力に切り替えて電気的に切り離す方式にした。

  それでもOFFにならない場合は、リレーモジュールの VCC を
  5V から 3.3V（1番ピン）に挿し替えると直ることが多い。

  起動時にバナーが出て、その時点でリレーのLEDが消えていれば正常。

【ノイズ対策】
  モーターのノイズでDHT22が読めなくなったり画面が消えたりする場合は、
  0.1µF(104)のセラミックコンデンサをポンプの＋－間に入れる

【追加配線】
  リレーモジュール  VCC → 5V  /  GND → GND  /  IN → GPIO17（物理11番）
  ※ ADC0834がGPIO18/23/24/25を使っているため、リレーは17に割り当てている
  ※ ポンプの電源は電池側で完結させる（PiのGNDと繋がない）
      電池(+) → リレーCOM  /  リレーNO → ポンプ(+)  /  ポンプ(-) → 電池(-)

【起動】
  source ~/farm-env/bin/activate
  cd ~/farm-status
  python3 server_phase2.py
  ※ status_phase2.html を同じフォルダに置いておくこと
"""

import atexit
import threading
import time
from pathlib import Path

import board
import adafruit_dht
from flask import Flask, jsonify, request, send_from_directory

import lgpio             # RPi.GPIO のシムを介さず直接叩く
import adc0834

DHT_PIN = board.D4
SOIL_ADC_CHANNEL = 0
READ_INTERVAL_SEC = 1   # 給水中の反応を速くするため1秒に

# 実測した較正値（乾燥 220 / 水中 127）※台ごとに書き換える
SOIL_RAW_DRY = 220
SOIL_RAW_WET = 127

# --- ポンプ設定 ---
RELAY_GPIO = 27
RELAY_ACTIVE_LOW = True   # 青い安価なリレーはほぼこれ。動きが逆なら False
PUMP_MAX_SEC = 15.0       # 安全装置：しきい値に達しなくてもここで必ず止める
SOAK_SEC = 3.0            # 給水後、水がしみ込むのを待つ時間
COOLDOWN_SEC = 2.0        # 連続作動の防止
STOP_MARGIN = 0           # しきい値＋この値まで上がったら停止（0＝しきい値ちょうど）
THRESHOLD_MIN = 10        # スライダーで設定できる下限
THRESHOLD_MAX = 80        # 同上限

# --- 誤作動対策 ---
DRY_COUNT_NEEDED = 3      # 連続で何回下回ったら水をやるか（2秒×3回＝約6秒）
MAX_CONTINUOUS_WATER = 5  # 連続で何回水をやっても改善しなければ自動を止める

HTML_FILE = "status_phase2.html"
HTML_DIR = Path(__file__).parent

app = Flask(__name__)
dht = adafruit_dht.DHT22(DHT_PIN, use_pulseio=False)
adc0834.setup()

RELAY_OFF = 1 if RELAY_ACTIVE_LOW else 0
RELAY_ON = 0 if RELAY_ACTIVE_LOW else 1


def _find_gpiochip():
    """40ピンヘッダに対応する gpiochip を自動判別する。
    Pi 5 ではラベルが pinctrl-rp1 のチップ（多くは gpiochip15）。"""
    import glob
    import os
    for path in sorted(glob.glob("/sys/bus/gpio/devices/gpiochip*")):
        try:
            with open(os.path.join(path, "label")) as f:
                label = f.read().strip()
        except OSError:
            continue
        if "pinctrl-rp1" in label or "pinctrl-bcm" in label:
            return int(os.path.basename(path).replace("gpiochip", ""))
    return 0


_CHIP = _find_gpiochip()
_h = lgpio.gpiochip_open(_CHIP)

# --- リレーの駆動方式 -------------------------------------------------
# 安価なリレーモジュールは VCC=5V で動くが、Piの HIGH は 3.3V しかない。
# その差 1.7V でフォトカプラが光り続け、HIGH を出しても OFF にならない
# ことがある（IN線を抜いたときだけ消える、という症状になる）。
#
# そこで OFF のときは HIGH を出すのではなく、ピンを入力に切り替えて
# 電気的に切り離す（ハイインピーダンス）。IN線を抜いたのと同じ状態。
#
#   "highz" … OFF でピンを入力にする（推奨。上記の症状に対応）
#   "level" … 従来どおり HIGH/LOW を出し分ける
RELAY_MODE = "highz"

_relay_is_on = False


def relay(on):
    """リレーを操作する。on=True で通水、False で停止。"""
    global _relay_is_on
    try:
        lgpio.gpio_free(_h, RELAY_GPIO)
    except Exception:
        pass
    if on:
        lgpio.gpio_claim_output(_h, RELAY_GPIO, RELAY_ON)
    elif RELAY_MODE == "highz":
        lgpio.gpio_claim_input(_h, RELAY_GPIO)   # 切り離す＝確実にOFF
    else:
        lgpio.gpio_claim_output(_h, RELAY_GPIO, RELAY_OFF)
    _relay_is_on = on


def relay_is_on():
    """いまリレーをONにしているか（プログラム側の認識）"""
    return _relay_is_on


relay(False)
print("=" * 56)
print(" server_phase2.py  v4  (highz方式 / しきい値まで給水)")
print(f" gpiochip{_CHIP} / GPIO{RELAY_GPIO} / RELAY_MODE={RELAY_MODE}")
print(" 起動した時点でリレーのLEDが消えていれば正常です")
print("=" * 56)

latest = {
    "soil": 50,
    "soil_live": True,
    "humidity": 55,
    "temperature": 24.0,
    "ok": False,
    "updated_at": None,
    # --- フェーズ2で追加 ---
    "pump": False,
    "threshold": 40,
    "auto": True,
    "water_count": 0,
}
lock = threading.Lock()

_pump_off_at = 0.0     # この時刻になったらポンプを止める
_soak_until = 0.0      # しみ込み待ちの終了時刻
_cooldown_until = 0.0
_dry_streak = 0           # 連続で乾いていた回数
_continuous_water = 0     # 水分が回復しないまま連続でかん水した回数


def soil_raw_to_percent(raw):
    """rawのADC値(0-255)を 0-100%（湿っているほど大きい値）に変換する"""
    pct = (SOIL_RAW_DRY - raw) / (SOIL_RAW_DRY - SOIL_RAW_WET) * 100
    return max(0, min(100, round(pct)))


def start_watering(reason):
    """ポンプを回し始める。実際に始めたら True を返す。
    呼び出し側で lock を取っていること。"""
    global _pump_off_at, _continuous_water
    now = time.time()

    # 作動中・しみ込み待ち・クールダウン中は何もしない
    if latest["pump"] or now < _soak_until or now < _cooldown_until:
        return False

    # 自動かん水のときだけ、連続作動の上限を見る
    if reason == "auto":
        if _continuous_water >= MAX_CONTINUOUS_WATER:
            latest["auto"] = False
            print("[PUMP] 水をやっても水分が上がらないため、自動かん水を停止しました")
            print("       センサーが土から抜けていないか確認してください")
            return False
        _continuous_water += 1

    relay(True)
    latest["pump"] = True
    latest["water_count"] += 1
    _pump_off_at = now + PUMP_MAX_SEC
    print(f"[PUMP] ON ({reason}) soil={latest['soil']}% → {latest['threshold']}%になるまで給水")
    return True


def stop_watering():
    """ポンプを止め、しみ込み待ちに入る。呼び出し側で lock を取っていること。"""
    global _soak_until, _cooldown_until
    relay(False)
    if latest["pump"]:
        print("[PUMP] OFF")
    latest["pump"] = False
    now = time.time()
    _soak_until = now + SOAK_SEC
    _cooldown_until = now + SOAK_SEC + COOLDOWN_SEC


def pump_watchdog():
    """0.1秒ごとに見張り、規定時間を過ぎたら必ずポンプを止める。
    センサーループとは別スレッドにして、DHT22が固まっても
    ポンプが回りっぱなしにならないようにしている。"""
    while True:
        with lock:
            if latest["pump"]:
                # ① しきい値に達したらすぐ止める（0.1秒ごとに見るので反応は速い）
                if latest["soil"] >= latest["threshold"] + STOP_MARGIN:
                    print(f"[PUMP] しきい値に到達（{latest['soil']}%）")
                    stop_watering()
                # ② 達しなくても最長時間で強制停止（空回し・水切れ対策）
                elif time.time() >= _pump_off_at:
                    print(f"[PUMP] {PUMP_MAX_SEC:.0f}秒たっても届かないので停止します")
                    stop_watering()
            elif relay_is_on():
                # 命令していないのにリレーがONのままなら強制的に消す
                relay(False)
        time.sleep(0.1)


def sensor_loop():
    global _dry_streak, _continuous_water
    while True:
        # --- 土壌水分（DHT22とは独立して必ず更新する）---
        try:
            soil_raw = adc0834.read_average(SOIL_ADC_CHANNEL)
            soil_pct = soil_raw_to_percent(soil_raw)
            with lock:
                latest["soil"] = soil_pct
                latest["updated_at"] = time.time()
                latest["ok"] = True

                # --- 自動かん水の判定 ---
                if soil_pct < latest["threshold"]:
                    _dry_streak += 1
                else:
                    # 十分に湿った → 一瞬の異常値も連続作動もリセット
                    _dry_streak = 0
                    _continuous_water = 0

                # 連続して乾いていたときだけ水をやる
                if latest["auto"] and _dry_streak >= DRY_COUNT_NEEDED:
                    start_watering("auto")
            print(f"[OK] soil_raw={soil_raw:.1f} soil%={soil_pct}")
        except Exception as e:
            print(f"[ERROR] soil read error: {e}")

        # --- 気温・湿度（コケても土壌水分には影響させない）---
        try:
            temperature = dht.temperature
            humidity = dht.humidity
            if temperature is not None and humidity is not None:
                with lock:
                    latest["humidity"] = round(humidity)
                    latest["temperature"] = round(temperature, 1)
                print(f"[OK] hum={humidity:.1f} temp={temperature:.1f}")
            else:
                print("[WARN] DHT22 read returned None")
        except RuntimeError as e:
            print(f"[WARN] DHT22 read error: {e}")
        except Exception as e:
            print(f"[ERROR] unexpected DHT error: {e}")

        time.sleep(READ_INTERVAL_SEC)


@app.route("/api/status")
def status():
    with lock:
        return jsonify(dict(latest))


@app.route("/api/threshold", methods=["POST"])
def set_threshold():
    """ブラウザのスライダーからしきい値を変更する"""
    global _dry_streak
    data = request.get_json(silent=True) or {}
    try:
        value = int(data.get("value"))
    except (TypeError, ValueError):
        return jsonify({"ok": False, "error": "value must be a number"}), 400
    value = max(THRESHOLD_MIN, min(THRESHOLD_MAX, value))
    with lock:
        latest["threshold"] = value
        _dry_streak = 0   # 基準が変わったので数え直す
    print(f"[SET] threshold={value}%")
    return jsonify({"ok": True, "threshold": value})


@app.route("/api/water", methods=["POST"])
def water_now():
    """「いますぐ みずやり」ボタン。自動が停止していても手動なら作動する。"""
    with lock:
        accepted = start_watering("manual")
    return jsonify({"ok": True, "accepted": accepted})


@app.route("/api/stop", methods=["POST"])
def stop_now():
    """「みずやりを とめる」ボタン。
    いま出ている水をすぐ止め、自動かん水も切る。
    当日のトラブル時に最初に押すボタン。"""
    with lock:
        relay(False)
        latest["pump"] = False
        latest["auto"] = False
    print("[PUMP] 手動停止しました（自動かん水も停止）")
    return jsonify({"ok": True, "auto": False})


@app.route("/api/auto", methods=["POST"])
def set_auto():
    """自動かん水のON/OFF。ONにすると連続作動のカウンタもリセットされる。"""
    global _continuous_water, _dry_streak
    data = request.get_json(silent=True) or {}
    enabled = bool(data.get("enabled", True))
    with lock:
        latest["auto"] = enabled
        if enabled:
            _continuous_water = 0
            _dry_streak = 0
    print(f"[SET] auto={enabled}")
    return jsonify({"ok": True, "auto": enabled})


@app.route("/")
def index():
    return send_from_directory(HTML_DIR, HTML_FILE)


@atexit.register
def shutdown():
    """どんな終わり方をしてもポンプは必ず止める"""
    try:
        relay(False)
        lgpio.gpiochip_close(_h)
    except Exception:
        pass


if __name__ == "__main__":
    threading.Thread(target=sensor_loop, daemon=True).start()
    threading.Thread(target=pump_watchdog, daemon=True).start()
    try:
        app.run(host="0.0.0.0", port=5000)
    finally:
        shutdown()
