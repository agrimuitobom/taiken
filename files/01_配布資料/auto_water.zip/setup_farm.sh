#!/bin/bash
# =====================================================================
# 「畑のステータス」フェーズ2 セットアップスクリプト
# =====================================================================
# 使い方（1台につき1回）:
#   chmod +x setup_farm.sh
#   ./setup_farm.sh
#
# このスクリプトがやること:
#   1. コンパイルに必要な apt パッケージを入れる
#   2. ~/farm-env の venv を作る
#   3. Python ライブラリを入れる
#   4. 入ったかどうかを確認して表示する
#
# ※ ネットワークが不安定なときは途中で失敗します。
#    その場合はもう一度このスクリプトを実行してください。
#    何度実行しても壊れません。
# =====================================================================

set -e

echo ""
echo "=================================================="
echo " フェーズ2 セットアップを開始します"
echo "=================================================="
echo ""

# --- 1. apt パッケージ ---------------------------------------------
echo "[1/4] コンパイル用の道具を入れています..."
sudo apt update
sudo apt install -y swig python3-dev build-essential liblgpio-dev
echo "  → OK"
echo ""

# --- 古い RPi.GPIO が混ざっていないか確認 ---------------------------
if dpkg -l | grep -qi "python3-rpi.gpio"; then
    echo "  ⚠ 警告: python3-rpi.gpio が入っています。"
    echo "    Pi5 では動かないため、次のコマンドで削除してください:"
    echo "      sudo apt remove python3-rpi.gpio"
    echo ""
fi

# --- 2. venv --------------------------------------------------------
echo "[2/4] 仮想環境 ~/farm-env を作っています..."
if [ -d "$HOME/farm-env" ]; then
    echo "  既に存在します。作り直す場合は先に rm -rf ~/farm-env を実行してください。"
else
    python3 -m venv "$HOME/farm-env"
    echo "  → OK"
fi
echo ""

# --- 3. pip ---------------------------------------------------------
echo "[3/4] Python ライブラリを入れています（1〜2分かかります）..."
source "$HOME/farm-env/bin/activate"
pip install --upgrade pip
pip install lgpio rpi-lgpio adafruit-circuitpython-dht flask flask-cors
echo "  → OK"
echo ""

# --- 4. 確認 --------------------------------------------------------
echo "[4/4] 確認しています..."
MISSING=0
for MOD in board lgpio flask adafruit_dht; do
    if python3 -c "import $MOD" 2>/dev/null; then
        echo "  ✓ $MOD"
    else
        echo "  ✗ $MOD が読み込めません"
        MISSING=1
    fi
done
echo ""

if [ "$MISSING" -eq 1 ]; then
    echo "=================================================="
    echo " 一部のライブラリが入っていません。"
    echo " もう一度このスクリプトを実行してください。"
    echo "=================================================="
    exit 1
fi

echo "=================================================="
echo " セットアップ完了"
echo "=================================================="
echo ""
echo " 次にやること:"
echo ""
echo "  1. server_phase2.py / status_phase2.html / adc0834.py を"
echo "     同じフォルダに置く"
echo ""
echo "  2. 起動する"
echo "       source ~/farm-env/bin/activate"
echo "       python3 server_phase2.py"
echo ""
echo "  3. ログの soil_raw を確認する"
echo "       255 のまま  → センサーの VCC / GND / AOUT を確認"
echo "       0 のまま    → AOUT が電源に触れていないか確認"
echo "       数字が動く  → 正常"
echo ""
echo "  4. 空気中と水中の soil_raw を測り、server_phase2.py の"
echo "     SOIL_RAW_DRY と SOIL_RAW_WET をこの台の値に書き換える"
echo "     （台ごとに必ず測り直すこと）"
echo ""
echo "  5. ポンプ未接続のまま「いますぐ みずやり」を押し、"
echo "     カチッ→3秒→カチッ と鳴ることを確認してから"
echo "     ポンプを繋ぐ"
echo ""
echo " この台の IP アドレス:"
hostname -I
echo ""
